package ua.com.reactive.airline_company.router;

import ua.com.reactive.airline_company.handler.FlightHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;

@Configuration
public class FlightRouter {

    @Bean
    public RouterFunction<?> route(FlightHandler flightHandler) {
        return RouterFunctions
                .route(RequestPredicates.GET("/flights").and(RequestPredicates.accept(MediaType.APPLICATION_JSON)), flightHandler::getFlights)
                .andRoute(RequestPredicates.GET("/crew").and(RequestPredicates.accept(MediaType.APPLICATION_JSON)), flightHandler::getCrewMembers);
    }
}
