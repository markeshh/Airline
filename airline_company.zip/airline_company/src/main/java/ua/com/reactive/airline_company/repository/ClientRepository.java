package ua.com.reactive.airline_company.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import ua.com.reactive.airline_company.entity.Client;

public interface ClientRepository extends ReactiveCrudRepository<Client, Long> {
}
