package ua.com.reactive.airline_company.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.com.reactive.airline_company.entity.Client;
import ua.com.reactive.airline_company.service.ClientService;

@RestController
@RequestMapping("/clients")
public class ClientController {

    private final ClientService clientService;

    @Autowired
    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping
    public Flux<Client> getClients() {
        return clientService.list();
    }

    @PostMapping
    public Mono<Client> createClient(@RequestBody Client client) {
        return clientService.addOne(client);
    }
}
