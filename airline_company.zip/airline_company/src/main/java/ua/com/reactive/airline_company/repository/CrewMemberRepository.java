package ua.com.reactive.airline_company.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import ua.com.reactive.airline_company.entity.CrewMember;

public interface CrewMemberRepository extends ReactiveCrudRepository<CrewMember, Long> {
}
