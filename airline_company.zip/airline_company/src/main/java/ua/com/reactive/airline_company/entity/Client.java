package ua.com.reactive.airline_company.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Client {

    private Long id;
    private String firstName;
    private String lastName;
    private int age;
    private String flightNumber; // Номер рейсу
    private Object otherDetails;  // Для додаткових даних, якщо потрібно
}
