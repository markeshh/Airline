package ua.com.reactive.airline_company.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.com.reactive.airline_company.entity.Message;
import ua.com.reactive.airline_company.service.MessageService;

@RestController
@RequestMapping("/messages")
public class MainController {

    private final MessageService messageService;

    @Autowired
    public MainController(MessageService messageService) {
        this.messageService = messageService;
    }

    @GetMapping
    public Flux<Message> getMessages() {
        return messageService.list();
    }

    @PostMapping
    public Mono<Message> createMessage(@RequestBody Message message) {
        return messageService.addOne(message);
    }
}
