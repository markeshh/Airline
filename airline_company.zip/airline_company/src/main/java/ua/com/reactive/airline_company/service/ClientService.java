package ua.com.reactive.airline_company.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.com.reactive.airline_company.entity.Client;
import ua.com.reactive.airline_company.repository.ClientRepository;

@Service
public class ClientService {
    private final ClientRepository clientRepository;

    @Autowired
    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public Flux<Client> list() {
        return clientRepository.findAll();
    }

    public Mono<Client> addOne(Client client) {
        return clientRepository.save(client);
    }
}
