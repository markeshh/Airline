package ua.com.reactive.airline_company.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.com.reactive.airline_company.entity.Flight;
import ua.com.reactive.airline_company.service.FlightService;
import ua.com.reactive.airline_company.entity.CrewMember;
import ua.com.reactive.airline_company.service.CrewMemberService;


@RestController
@RequestMapping("/flights")
public class FlightController {

    private final FlightService flightService;
    private final CrewMemberService crewMemberService;

    @Autowired
    public FlightController(FlightService flightService, CrewMemberService crewMemberService) {
        this.flightService = flightService;
        this.crewMemberService = crewMemberService;
    }

    @GetMapping
    public Flux<Flight> getFlights() {
        return flightService.list();
    }

    @PostMapping
    public Mono<Flight> createFlight(@RequestBody Flight flight) {
        return flightService.addOne(flight);
    }

    @GetMapping("/crew")
    public Flux<CrewMember> getCrewMembers() {
        return crewMemberService.list();
    }

    @PostMapping("/crew")
    public Mono<CrewMember> createCrewMember(@RequestBody CrewMember crewMember) {
        return crewMemberService.addOne(crewMember);
    }
}
