package ua.com.reactive.airline_company.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.com.reactive.airline_company.entity.CrewMember;
import ua.com.reactive.airline_company.repository.CrewMemberRepository;

@Service
public class CrewMemberService {
    private final CrewMemberRepository crewMemberRepository;

    @Autowired
    public CrewMemberService(CrewMemberRepository crewMemberRepository) {
        this.crewMemberRepository = crewMemberRepository;
    }

    public Flux<CrewMember> list() {
        return crewMemberRepository.findAll();
    }

    public Mono<CrewMember> addOne(CrewMember crewMember) {
        return crewMemberRepository.save(crewMember);
    }
}
