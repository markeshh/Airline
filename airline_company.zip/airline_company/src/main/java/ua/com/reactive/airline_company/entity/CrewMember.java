package ua.com.reactive.airline_company.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CrewMember {
    private Long id;
    private String firstName;
    private String lastName;
    private String role;  // Наприклад, пілот, штурман, стюардеса
}
