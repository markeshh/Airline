package ua.com.reactive.airline_company.handler;

import ua.com.reactive.airline_company.entity.Flight;
import ua.com.reactive.airline_company.entity.CrewMember;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class FlightHandler {

    public Mono<ServerResponse> getFlights(ServerRequest request) {
        Flux<Flight> flights = Flux.just(
                new Flight(1L, "AI101", "New York", "London", "2024-12-01T14:00", "2024-12-01T18:00"),
                new Flight(2L, "AI102", "London", "Paris", "2024-12-02T10:00", "2024-12-02T11:30")
        );
        return ServerResponse
                .ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(flights, Flight.class);
    }

    public Mono<ServerResponse> getCrewMembers(ServerRequest request) {
        Flux<CrewMember> crewMembers = Flux.just(
                new CrewMember(1L, "John", "Doe", "Pilot"),
                new CrewMember(2L, "Jane", "Smith", "Stewardess")
        );
        return ServerResponse
                .ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(crewMembers, CrewMember.class);
    }
}
