package ua.com.reactive.airline_company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineCompanyApplication {

    public static void main(String[] args) {
        SpringApplication.run(AirlineCompanyApplication.class, args);
    }

}
