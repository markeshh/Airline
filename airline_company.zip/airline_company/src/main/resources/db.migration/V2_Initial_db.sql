-- V2__Initial_db.sql

-- Таблиця для клієнтів
CREATE TABLE clients (
                         id BIGSERIAL PRIMARY KEY,                  -- Унікальний ідентифікатор
                         first_name VARCHAR(100) NOT NULL,           -- Ім'я клієнта
                         last_name VARCHAR(100) NOT NULL,            -- Прізвище клієнта
                         age INT NOT NULL,                           -- Вік клієнта
                         flight_number VARCHAR(10) NOT NULL          -- Номер рейсу, на якому летить клієнт
);

-- Таблиця для членів екіпажу
CREATE TABLE crew_members (
                              id BIGSERIAL PRIMARY KEY,                  -- Унікальний ідентифікатор
                              first_name VARCHAR(100) NOT NULL,           -- Ім'я члена екіпажу
                              last_name VARCHAR(100) NOT NULL,            -- Прізвище члена екіпажу
                              role VARCHAR(100) NOT NULL                  -- Роль (пілот, стюардеса тощо)
);

-- Таблиця для рейсів
CREATE TABLE flights (
                         id BIGSERIAL PRIMARY KEY,                  -- Унікальний ідентифікатор
                         flight_number VARCHAR(10) NOT NULL,         -- Номер рейсу
                         origin VARCHAR(100) NOT NULL,               -- Місто відправлення
                         destination VARCHAR(100) NOT NULL,          -- Місто призначення
                         departure_time TIMESTAMP NOT NULL,          -- Час відправлення
                         arrival_time TIMESTAMP NOT NULL             -- Час прибуття
);

-- Створення зв'язків між таблицями
-- Прив'язка клієнта до рейсу через поле flight_number
ALTER TABLE clients
    ADD flight_id BIGINT,
    ADD CONSTRAINT fk_flight_id
        FOREIGN KEY (flight_id) REFERENCES flights(id);

-- Для можливого зв'язку між екіпажем і рейсами (за потребою, якщо один рейс має кілька членів екіпажу)
-- Створимо допоміжну таблицю для зв'язку між екіпажем та рейсами
CREATE TABLE flight_crew (
                             flight_id BIGINT NOT NULL,
                             crew_member_id BIGINT NOT NULL,
                             PRIMARY KEY (flight_id, crew_member_id),
                             CONSTRAINT fk_flight FOREIGN KEY (flight_id) REFERENCES flights(id),
                             CONSTRAINT fk_crew_member FOREIGN KEY (crew_member_id) REFERENCES crew_members(id)
);
