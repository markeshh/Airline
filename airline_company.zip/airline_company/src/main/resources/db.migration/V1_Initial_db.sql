CREATE TABLE message (
                         id bigserial PRIMARY KEY,
                         data VARCHAR(1024)
);