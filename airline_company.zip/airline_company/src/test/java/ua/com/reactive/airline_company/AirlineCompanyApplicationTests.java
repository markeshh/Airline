package ua.com.reactive.airline_company;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineCompanyApplicationTests {

    @Test
    void contextLoads() {
    }

}
